module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      [
        "babel-preset-expo",
        {
          unstable_transformImportMeta: true,
        },
      ],
    ],
    plugins: [
      // Strip dead code and apply extra minification hints
      "babel-plugin-transform-remove-console",
    ],
    env: {
      production: {
        plugins: ["transform-remove-console"],
      },
    },
  };
};
