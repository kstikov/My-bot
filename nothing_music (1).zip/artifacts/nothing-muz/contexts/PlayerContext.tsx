import AsyncStorage from "@react-native-async-storage/async-storage";
import { Audio, AVPlaybackStatus } from "expo-av";
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";

export interface Track {
  id: string;
  title: string;
  artist: string;
  cover_url: string;
  duration: number;
  stream_url: string;
  source?: "local" | "vk" | "yandex" | "spotify";
}

interface PlayerState {
  playlist: Track[];
  currentIndex: number;
  isPlaying: boolean;
  progress: number;
  duration: number;
  isShuffle: boolean;
  isRepeat: boolean;
}

interface PlayerContextType extends PlayerState {
  currentTrack: Track | null;
  play: (track?: Track, playlist?: Track[]) => Promise<void>;
  pause: () => Promise<void>;
  togglePlay: () => Promise<void>;
  next: () => Promise<void>;
  prev: () => Promise<void>;
  seekTo: (seconds: number) => Promise<void>;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  addToLibrary: (tracks: Track[]) => void;
  removeFromLibrary: (id: string) => void;
}

const STORAGE_KEY = "nothing_muz_library";

const DEMO_TRACKS: Track[] = [
  {
    id: "demo_1",
    title: "SYSTEM OVERRIDE",
    artist: "NOTHING AUDIO",
    cover_url: "",
    duration: 210,
    stream_url: "",
    source: "local",
  },
  {
    id: "demo_2",
    title: "DOT MATRIX DREAMS",
    artist: "GLYPH ENGINE",
    cover_url: "",
    duration: 183,
    stream_url: "",
    source: "local",
  },
  {
    id: "demo_3",
    title: "PHONE (2) AMBIENT",
    artist: "NOTHING LABS",
    cover_url: "",
    duration: 264,
    stream_url: "",
    source: "local",
  },
  {
    id: "demo_4",
    title: "TRANSPARENT NOISE",
    artist: "CMF SOUND",
    cover_url: "",
    duration: 197,
    stream_url: "",
    source: "local",
  },
  {
    id: "demo_5",
    title: "BOOT SEQUENCE",
    artist: "OS KERNEL",
    cover_url: "",
    duration: 145,
    stream_url: "",
    source: "local",
  },
  {
    id: "demo_6",
    title: "HAPTIC FEEDBACK",
    artist: "VIBRATION UNIT",
    cover_url: "",
    duration: 228,
    stream_url: "",
    source: "local",
  },
];

const PlayerContext = createContext<PlayerContextType | null>(null);

export function PlayerProvider({ children }: { children: React.ReactNode }) {
  const soundRef = useRef<Audio.Sound | null>(null);
  const [playlist, setPlaylist] = useState<Track[]>(DEMO_TRACKS);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [isRepeat, setIsRepeat] = useState<boolean>(false);
  const progressTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const fakeProgressRef = useRef<number>(0);

  useEffect(() => {
    Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      staysActiveInBackground: true,
      playsInSilentModeIOS: true,
    });
    loadLibrary();
    return () => {
      if (progressTimer.current) clearInterval(progressTimer.current);
      soundRef.current?.unloadAsync();
    };
  }, []);

  async function loadLibrary() {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        const saved: Track[] = JSON.parse(stored);
        if (saved.length > 0) {
          setPlaylist((prev) => {
            const ids = new Set(prev.map((t) => t.id));
            const merged = [...prev, ...saved.filter((t) => !ids.has(t.id))];
            return merged;
          });
        }
      }
    } catch {}
  }

  function startFakeProgress(track: Track) {
    fakeProgressRef.current = 0;
    setProgress(0);
    setDuration(track.duration);
    if (progressTimer.current) clearInterval(progressTimer.current);
    progressTimer.current = setInterval(() => {
      fakeProgressRef.current += 1;
      if (fakeProgressRef.current >= track.duration) {
        fakeProgressRef.current = 0;
        setProgress(0);
        setIsPlaying(false);
        if (progressTimer.current) clearInterval(progressTimer.current);
      } else {
        setProgress(fakeProgressRef.current);
      }
    }, 1000);
  }

  function stopFakeProgress() {
    if (progressTimer.current) clearInterval(progressTimer.current);
    progressTimer.current = null;
  }

  async function loadAndPlay(track: Track) {
    try {
      if (soundRef.current) {
        await soundRef.current.unloadAsync();
        soundRef.current = null;
      }
      stopFakeProgress();

      if (!track.stream_url) {
        setIsPlaying(true);
        startFakeProgress(track);
        return;
      }

      const { sound } = await Audio.Sound.createAsync(
        { uri: track.stream_url },
        { shouldPlay: true, progressUpdateIntervalMillis: 500 }
      );
      soundRef.current = sound;
      sound.setOnPlaybackStatusUpdate((status: AVPlaybackStatus) => {
        if (!status.isLoaded) return;
        setIsPlaying(status.isPlaying);
        setProgress(status.positionMillis / 1000);
        setDuration((status.durationMillis ?? 0) / 1000);
        if (status.didJustFinish) {
          setIsPlaying(false);
        }
      });
      setIsPlaying(true);
    } catch {
      setIsPlaying(true);
      startFakeProgress(track);
    }
  }

  const play = useCallback(
    async (track?: Track, newPlaylist?: Track[]) => {
      if (newPlaylist) setPlaylist(newPlaylist);
      const targetPlaylist = newPlaylist ?? playlist;
      if (track) {
        const idx = targetPlaylist.findIndex((t) => t.id === track.id);
        const finalIdx = idx >= 0 ? idx : 0;
        setCurrentIndex(finalIdx);
        await loadAndPlay(track);
      } else {
        const current = targetPlaylist[currentIndex];
        if (current) await loadAndPlay(current);
      }
    },
    [playlist, currentIndex]
  );

  const pause = useCallback(async () => {
    if (soundRef.current) {
      await soundRef.current.pauseAsync();
    } else {
      stopFakeProgress();
    }
    setIsPlaying(false);
  }, []);

  const togglePlay = useCallback(async () => {
    if (isPlaying) {
      await pause();
    } else {
      if (soundRef.current) {
        await soundRef.current.playAsync();
        setIsPlaying(true);
      } else {
        const current = playlist[currentIndex];
        if (current) await loadAndPlay(current);
      }
    }
  }, [isPlaying, pause, playlist, currentIndex]);

  const next = useCallback(async () => {
    let nextIdx: number;
    if (isShuffle) {
      nextIdx = Math.floor(Math.random() * playlist.length);
    } else {
      nextIdx = (currentIndex + 1) % playlist.length;
    }
    setCurrentIndex(nextIdx);
    await loadAndPlay(playlist[nextIdx]);
  }, [currentIndex, playlist, isShuffle]);

  const prev = useCallback(async () => {
    if (progress > 3) {
      await seekTo(0);
      return;
    }
    const prevIdx = currentIndex === 0 ? playlist.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIdx);
    await loadAndPlay(playlist[prevIdx]);
  }, [currentIndex, playlist, progress]);

  const seekTo = useCallback(async (seconds: number) => {
    if (soundRef.current) {
      await soundRef.current.setPositionAsync(seconds * 1000);
    } else {
      fakeProgressRef.current = seconds;
      setProgress(seconds);
    }
  }, []);

  const toggleShuffle = useCallback(() => setIsShuffle((s) => !s), []);
  const toggleRepeat = useCallback(() => setIsRepeat((r) => !r), []);

  const addToLibrary = useCallback(async (tracks: Track[]) => {
    setPlaylist((prev) => {
      const ids = new Set(prev.map((t) => t.id));
      const merged = [...prev, ...tracks.filter((t) => !ids.has(t.id))];
      AsyncStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(merged.filter((t) => t.source !== "local"))
      );
      return merged;
    });
  }, []);

  const removeFromLibrary = useCallback((id: string) => {
    setPlaylist((prev) => {
      const updated = prev.filter((t) => t.id !== id);
      AsyncStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(updated.filter((t) => t.source !== "local"))
      );
      return updated;
    });
  }, []);

  const currentTrack = playlist[currentIndex] ?? null;

  return (
    <PlayerContext.Provider
      value={{
        playlist,
        currentIndex,
        isPlaying,
        progress,
        duration,
        isShuffle,
        isRepeat,
        currentTrack,
        play,
        pause,
        togglePlay,
        next,
        prev,
        seekTo,
        toggleShuffle,
        toggleRepeat,
        addToLibrary,
        removeFromLibrary,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
}

export function usePlayer() {
  const ctx = useContext(PlayerContext);
  if (!ctx) throw new Error("usePlayer must be used within PlayerProvider");
  return ctx;
}
