import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export type ServiceId = "vk" | "yandex" | "spotify";

export interface ServiceInfo {
  id: ServiceId;
  name: string;
  color: string;
  description: string;
  tokenLabel: string;
  howToGet: string;
}

export const SERVICES: ServiceInfo[] = [
  {
    id: "vk",
    name: "VK MUSIC",
    color: "#0077FF",
    description: "Миллионы треков из ВКонтакте",
    tokenLabel: "VK Access Token",
    howToGet:
      "Получи токен через VK OAuth. Открой vk.com, зайди в настройки → безопасность → активные сессии.",
  },
  {
    id: "yandex",
    name: "ЯНДЕКС МУЗЫКА",
    color: "#FFCC00",
    description: "Треки и подкасты Яндекс Музыки",
    tokenLabel: "Yandex Music Token",
    howToGet:
      "Открой music.yandex.ru, нажми F12 → Хранилище → Куки → yandex_music_access_token",
  },
  {
    id: "spotify",
    name: "SPOTIFY",
    color: "#1DB954",
    description: "Стриминг через Spotify Web API",
    tokenLabel: "Spotify Access Token",
    howToGet:
      "Открой developer.spotify.com → Dashboard → создай приложение и получи токен через OAuth.",
  },
];

interface ConnectedService {
  id: ServiceId;
  token: string;
  connectedAt: number;
}

interface ServicesContextType {
  connected: Record<ServiceId, ConnectedService | null>;
  connect: (id: ServiceId, token: string) => Promise<void>;
  disconnect: (id: ServiceId) => Promise<void>;
  isConnected: (id: ServiceId) => boolean;
  getToken: (id: ServiceId) => string | null;
}

const STORAGE_KEY = "nothing_muz_services";

const ServicesContext = createContext<ServicesContextType | null>(null);

export function ServicesProvider({ children }: { children: React.ReactNode }) {
  const [connected, setConnected] = useState<
    Record<ServiceId, ConnectedService | null>
  >({
    vk: null,
    yandex: null,
    spotify: null,
  });

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setConnected(JSON.parse(stored));
      }
    } catch {}
  }

  async function save(updated: Record<ServiceId, ConnectedService | null>) {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }

  async function connect(id: ServiceId, token: string) {
    const updated = {
      ...connected,
      [id]: { id, token, connectedAt: Date.now() },
    };
    setConnected(updated);
    await save(updated);
  }

  async function disconnect(id: ServiceId) {
    const updated = { ...connected, [id]: null };
    setConnected(updated);
    await save(updated);
  }

  function isConnected(id: ServiceId) {
    return connected[id] !== null;
  }

  function getToken(id: ServiceId) {
    return connected[id]?.token ?? null;
  }

  return (
    <ServicesContext.Provider
      value={{ connected, connect, disconnect, isConnected, getToken }}
    >
      {children}
    </ServicesContext.Provider>
  );
}

export function useServices() {
  const ctx = useContext(ServicesContext);
  if (!ctx) throw new Error("useServices must be used within ServicesProvider");
  return ctx;
}
