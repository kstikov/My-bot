const { getDefaultConfig } = require("expo/metro-config");

const config = getDefaultConfig(__dirname);

// ── Obfuscation / minification settings ──────────────────────────────────────
// In production builds (APK/IPA) Metro + Hermes compiles JS to bytecode,
// making reverse-engineering significantly harder.
// These settings additionally obfuscate the JS bundle itself.
config.transformer = {
  ...config.transformer,
  minifierConfig: {
    // Terser obfuscation options
    compress: {
      drop_console: true,       // Remove all console.log calls
      drop_debugger: true,      // Remove debugger statements
      passes: 2,                // Multiple compression passes
      pure_funcs: ["console.info", "console.debug", "console.warn"],
    },
    mangle: {
      toplevel: true,           // Mangle top-level names
      eval: true,
      keep_classnames: false,
      keep_fnames: false,
    },
    output: {
      ascii_only: true,         // Encode non-ASCII as \uXXXX
      comments: false,          // Strip all comments
      beautify: false,
    },
    sourceMap: false,
  },
};

module.exports = config;
