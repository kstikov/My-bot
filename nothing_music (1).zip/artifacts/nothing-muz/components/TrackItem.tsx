import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import React from "react";
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { Track } from "@/contexts/PlayerContext";
import { useColors } from "@/hooks/useColors";

interface Props {
  track: Track;
  isActive?: boolean;
  isPlaying?: boolean;
  onPress: () => void;
  onLongPress?: () => void;
  index?: number;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

const sourceColors: Record<string, string> = {
  vk: "#0077FF",
  yandex: "#FFCC00",
  spotify: "#1DB954",
  local: "#555555",
};

const sourceLabels: Record<string, string> = {
  vk: "VK",
  yandex: "YA",
  spotify: "SP",
  local: "LO",
};

export function TrackItem({
  track,
  isActive,
  isPlaying,
  onPress,
  onLongPress,
  index,
}: Props) {
  const colors = useColors();

  function handlePress() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onPress();
  }

  const sourceColor = sourceColors[track.source ?? "local"];
  const sourceLabel = sourceLabels[track.source ?? "local"];

  return (
    <Pressable
      onPress={handlePress}
      onLongPress={onLongPress}
      style={({ pressed }) => [
        styles.container,
        {
          backgroundColor: isActive
            ? colors.secondary
            : pressed
              ? colors.card
              : "transparent",
          borderBottomColor: colors.border,
        },
      ]}
    >
      <View style={styles.left}>
        {track.cover_url ? (
          <Image
            source={{ uri: track.cover_url }}
            style={[
              styles.cover,
              {
                borderColor: isActive ? colors.accent : colors.border,
                borderWidth: 1,
              },
            ]}
            contentFit="cover"
          />
        ) : (
          <View
            style={[
              styles.coverPlaceholder,
              {
                backgroundColor: colors.card,
                borderColor: isActive ? colors.accent : colors.border,
                borderWidth: 1,
              },
            ]}
          >
            <Text style={[styles.coverIndex, { color: colors.mutedForeground, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}>
              {index !== undefined ? String(index + 1).padStart(2, "0") : "··"}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.info}>
        <Text
          numberOfLines={1}
          style={[
            styles.title,
            {
              color: isActive ? colors.accent : colors.foreground,
              fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace',
            },
          ]}
        >
          {track.title.toUpperCase()}
        </Text>
        <Text
          numberOfLines={1}
          style={[styles.artist, { color: colors.mutedForeground, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}
        >
          {track.artist.toUpperCase()}
        </Text>
      </View>

      <View style={styles.right}>
        <View style={[styles.sourceBadge, { borderColor: sourceColor }]}>
          <Text style={[styles.sourceText, { color: sourceColor, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}>
            {sourceLabel}
          </Text>
        </View>
        {isActive && isPlaying ? (
          <Feather name="pause" size={14} color={colors.accent} />
        ) : (
          <Text style={[styles.duration, { color: colors.mutedForeground, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}>
            {formatDuration(track.duration)}
          </Text>
        )}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  left: {},
  cover: {
    width: 44,
    height: 44,
  },
  coverPlaceholder: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  coverIndex: {
    fontSize: 11,
  },
  info: {
    flex: 1,
    gap: 3,
  },
  title: {
    fontSize: 13,
    letterSpacing: 0.5,
  },
  artist: {
    fontSize: 11,
    letterSpacing: 0.3,
  },
  right: {
    alignItems: "flex-end",
    gap: 4,
  },
  sourceBadge: {
    borderWidth: 1,
    paddingHorizontal: 4,
    paddingVertical: 1,
  },
  sourceText: {
    fontSize: 9,
    letterSpacing: 1,
  },
  duration: {
    fontSize: 11,
  },
});
