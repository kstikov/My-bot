import React from "react";
import { Platform, StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";

interface Props {
  label?: string;
}

export function NothingDivider({ label }: Props) {
  const colors = useColors();
  const dot = "·";
  const dots = dot.repeat(6);

  return (
    <View style={styles.container}>
      <Text style={[styles.dots, { color: colors.border, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}>
        {dots}
      </Text>
      {label && (
        <Text
          style={[
            styles.label,
            { color: colors.mutedForeground, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' },
          ]}
        >
          {label.toUpperCase()}
        </Text>
      )}
      <Text style={[styles.dots, { color: colors.border, fontFamily: Platform.OS === 'ios' ? 'Courier New' : 'monospace' }]}>
        {dots}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 6,
    gap: 8,
  },
  dots: {
    flex: 1,
    letterSpacing: 4,
    fontSize: 10,
  },
  label: {
    fontSize: 10,
    letterSpacing: 2,
  },
});
