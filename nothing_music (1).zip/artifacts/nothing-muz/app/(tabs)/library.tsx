import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { Track, usePlayer } from "@/contexts/PlayerContext";
import { useColors } from "@/hooks/useColors";

const MONO = "SpaceMono_400Regular";
const NDOT = "SpaceMono_700Bold";

type TabType = "TRACKS" | "PLAYLISTS";

interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  expanded: boolean;
}

function formatDuration(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, "0")}`;
}

const sourceColors: Record<string, string> = {
  vk: "#0077FF",
  yandex: "#FFCC00",
  spotify: "#1DB954",
  local: "#555",
};

export default function LibraryScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { playlist, currentTrack, isPlaying, play, removeFromLibrary } = usePlayer();

  const [activeTab, setActiveTab] = useState<TabType>("TRACKS");
  const [search, setSearch] = useState("");
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [newPlName, setNewPlName] = useState("");
  const [addTrackModal, setAddTrackModal] = useState<string | null>(null);

  const filtered = playlist.filter(
    (t) =>
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      t.artist.toLowerCase().includes(search.toLowerCase())
  );

  function createPlaylist() {
    if (!newPlName.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setPlaylists((p) => [
      ...p,
      {
        id: Date.now().toString(),
        name: newPlName.trim().toUpperCase(),
        trackIds: [],
        expanded: false,
      },
    ]);
    setNewPlName("");
  }

  function toggleExpand(id: string) {
    setPlaylists((p) =>
      p.map((pl) => (pl.id === id ? { ...pl, expanded: !pl.expanded } : pl))
    );
  }

  function addToPlaylist(plId: string, trackId: string) {
    setPlaylists((p) =>
      p.map((pl) =>
        pl.id === plId
          ? { ...pl, trackIds: [...new Set([...pl.trackIds, trackId])] }
          : pl
      )
    );
    setAddTrackModal(null);
  }

  function playPlaylist(pl: Playlist) {
    const tracks = pl.trackIds
      .map((id) => playlist.find((t) => t.id === id))
      .filter(Boolean) as Track[];
    if (tracks.length > 0) play(tracks[0], tracks);
  }

  const renderTrack = ({ item, index }: { item: Track; index: number }) => {
    const isActive = currentTrack?.id === item.id;
    const sc = sourceColors[item.source ?? "local"];
    return (
      <Pressable
        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); play(item); }}
        style={({ pressed }) => [
          styles.trackRow,
          {
            backgroundColor: isActive
              ? "rgba(232,200,74,0.08)"
              : pressed
              ? "#0D0D0D"
              : "transparent",
            borderBottomColor: colors.border,
          },
        ]}
      >
        <Text style={[styles.trackNum, { color: colors.mutedForeground, fontFamily: MONO }]}>
          {String(index + 1).padStart(2, "0")}
        </Text>
        <View style={styles.trackMeta}>
          <Text
            numberOfLines={1}
            style={[
              styles.trackTitle,
              {
                color: isActive ? colors.accent : colors.foreground,
                fontFamily: isActive ? NDOT : MONO,
              },
            ]}
          >
            {item.title}
          </Text>
          <Text
            numberOfLines={1}
            style={[styles.trackArtist, { color: colors.mutedForeground, fontFamily: MONO }]}
          >
            {item.artist}
          </Text>
        </View>
        <View style={styles.trackRight}>
          <View style={[styles.sourceDot, { backgroundColor: sc }]} />
          {isActive && isPlaying ? (
            <Feather name="volume-2" size={13} color={colors.accent} />
          ) : (
            <Text style={[styles.trackDur, { color: colors.mutedForeground, fontFamily: MONO }]}>
              {formatDuration(item.duration)}
            </Text>
          )}
        </View>
      </Pressable>
    );
  };

  return (
    <View
      style={[
        styles.root,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === "web" ? 67 : insets.top,
        },
      ]}
    >
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: NDOT }]}>
          LIBRARY
        </Text>
        <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: MONO }]}>
          {playlist.length} TRACKS
        </Text>
      </View>

      {/* Tab switcher */}
      <View style={styles.tabSwitcher}>
        {(["TRACKS", "PLAYLISTS"] as TabType[]).map((tab) => (
          <TouchableOpacity
            key={tab}
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setActiveTab(tab); }}
            style={[
              styles.tabBtn,
              {
                backgroundColor:
                  activeTab === tab ? colors.foreground : "transparent",
                borderColor: colors.border,
              },
            ]}
          >
            <Text
              style={[
                styles.tabBtnText,
                {
                  color: activeTab === tab ? colors.background : colors.foreground,
                  fontFamily: MONO,
                },
              ]}
            >
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {activeTab === "TRACKS" ? (
        <>
          {/* Search */}
          <View style={[styles.searchRow, { borderColor: colors.border }]}>
            <Feather name="search" size={14} color={colors.mutedForeground} />
            <TextInput
              style={[styles.searchInput, { color: colors.foreground, fontFamily: MONO }]}
              placeholder="SEARCH..."
              placeholderTextColor={colors.mutedForeground}
              value={search}
              onChangeText={setSearch}
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")}>
                <Feather name="x" size={14} color={colors.mutedForeground} />
              </TouchableOpacity>
            )}
          </View>

          <FlatList
            data={filtered}
            keyExtractor={(t) => t.id}
            renderItem={renderTrack}
            scrollEnabled={filtered.length > 0}
            contentContainerStyle={{ paddingBottom: Platform.OS === "web" ? 34 : 0 }}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: MONO }]}>
                  NO TRACKS FOUND
                </Text>
              </View>
            }
          />
        </>
      ) : (
        <FlatList
          data={playlists}
          keyExtractor={(p) => p.id}
          contentContainerStyle={{ padding: 16, gap: 10, paddingBottom: Platform.OS === "web" ? 34 : 16 }}
          ListHeaderComponent={
            <View style={styles.createRow}>
              <TextInput
                style={[
                  styles.plInput,
                  {
                    backgroundColor: colors.card,
                    borderColor: colors.border,
                    color: colors.foreground,
                    fontFamily: MONO,
                  },
                ]}
                placeholder="PLAYLIST NAME"
                placeholderTextColor={colors.mutedForeground}
                value={newPlName}
                onChangeText={setNewPlName}
              />
              <TouchableOpacity
                onPress={createPlaylist}
                style={[styles.createBtn, { backgroundColor: colors.foreground }]}
              >
                <Text style={[styles.createBtnText, { color: colors.background, fontFamily: MONO }]}>
                  CREATE
                </Text>
              </TouchableOpacity>
            </View>
          }
          renderItem={({ item: pl }) => (
            <View
              style={[
                styles.plCard,
                { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius - 4 },
              ]}
            >
              <TouchableOpacity
                style={styles.plCardHeader}
                onPress={() => toggleExpand(pl.id)}
              >
                <Text style={[styles.plName, { color: colors.foreground, fontFamily: NDOT }]}>
                  PL {pl.name}
                </Text>
                <View style={styles.plActions}>
                  <TouchableOpacity
                    onPress={() => playPlaylist(pl)}
                    style={[styles.plPlayBtn, { borderColor: colors.accent }]}
                  >
                    <Feather name="play" size={12} color={colors.accent} />
                    <Text style={[styles.plPlayText, { color: colors.accent, fontFamily: MONO }]}>PLAY</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => setAddTrackModal(pl.id)}>
                    <Feather name="plus" size={18} color={colors.mutedForeground} />
                  </TouchableOpacity>
                  <Feather
                    name={pl.expanded ? "chevron-up" : "chevron-down"}
                    size={18}
                    color={colors.mutedForeground}
                  />
                </View>
              </TouchableOpacity>
              {pl.expanded && (
                <View style={[styles.plTrackList, { borderTopColor: colors.border }]}>
                  {pl.trackIds.length === 0 ? (
                    <Text style={[styles.plEmpty, { color: colors.mutedForeground, fontFamily: MONO }]}>
                      EMPTY PLAYLIST
                    </Text>
                  ) : (
                    pl.trackIds.map((tid) => {
                      const t = playlist.find((x) => x.id === tid);
                      if (!t) return null;
                      return (
                        <Text key={tid} style={[styles.plTrackItem, { color: colors.foreground, fontFamily: MONO }]}>
                          {t.title}
                        </Text>
                      );
                    })
                  )}
                </View>
              )}
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={[styles.emptyText, { color: colors.mutedForeground, fontFamily: MONO }]}>
                NO PLAYLISTS YET
              </Text>
            </View>
          }
        />
      )}

      {/* Add track to playlist modal */}
      <Modal
        visible={addTrackModal !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setAddTrackModal(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setAddTrackModal(null)}>
          <Pressable style={[styles.modalCard, { backgroundColor: "#1A1A1A", borderRadius: 28 }]}>
            <View style={[styles.modalHandle, { backgroundColor: colors.border }]} />
            <Text style={[styles.modalTitle, { color: colors.foreground, fontFamily: NDOT }]}>
              ADD TRACK
            </Text>
            <FlatList
              data={playlist}
              keyExtractor={(t) => t.id}
              style={{ maxHeight: 300 }}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => addToPlaylist(addTrackModal!, item.id)}
                  style={[styles.modalTrackRow, { borderBottomColor: colors.border }]}
                >
                  <Text style={[styles.modalTrackText, { color: colors.foreground, fontFamily: MONO }]}>
                    {item.title}
                  </Text>
                </TouchableOpacity>
              )}
            />
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
    paddingTop: 12,
    gap: 4,
  },
  headerTitle: { fontSize: 24, letterSpacing: 3 },
  headerSub: { fontSize: 10, letterSpacing: 2 },
  tabSwitcher: {
    flexDirection: "row",
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 40,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#252525",
  },
  tabBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
    borderRadius: 40,
  },
  tabBtnText: { fontSize: 12, letterSpacing: 2 },
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderRadius: 40,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 10,
  },
  searchInput: { flex: 1, fontSize: 12, letterSpacing: 1 },
  trackRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  trackNum: { width: 24, fontSize: 11, letterSpacing: 1 },
  trackMeta: { flex: 1, gap: 3 },
  trackTitle: { fontSize: 13, letterSpacing: 0.5 },
  trackArtist: { fontSize: 11, letterSpacing: 0.3 },
  trackRight: { alignItems: "flex-end", gap: 4 },
  sourceDot: { width: 6, height: 6, borderRadius: 3 },
  trackDur: { fontSize: 11 },
  empty: { alignItems: "center", paddingTop: 60 },
  emptyText: { fontSize: 12, letterSpacing: 2 },
  createRow: { flexDirection: "row", gap: 10, marginBottom: 16 },
  plInput: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 40,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 12,
    letterSpacing: 1,
  },
  createBtn: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 40,
    justifyContent: "center",
  },
  createBtnText: { fontSize: 12, letterSpacing: 1 },
  plCard: { borderWidth: 1, overflow: "hidden" },
  plCardHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 16,
  },
  plName: { fontSize: 14, letterSpacing: 1 },
  plActions: { flexDirection: "row", alignItems: "center", gap: 12 },
  plPlayBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
  },
  plPlayText: { fontSize: 11, letterSpacing: 1 },
  plTrackList: { borderTopWidth: StyleSheet.hairlineWidth, padding: 12, gap: 8 },
  plEmpty: { fontSize: 11, letterSpacing: 1, textAlign: "center", paddingVertical: 8 },
  plTrackItem: { fontSize: 12, letterSpacing: 0.5 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "flex-end" },
  modalCard: { padding: 24, paddingBottom: 40 },
  modalHandle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 12 },
  modalTitle: { fontSize: 16, letterSpacing: 2, marginBottom: 8 },
  modalTrackRow: { paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  modalTrackText: { fontSize: 13, letterSpacing: 0.5 },
});
