import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { usePlayer } from "@/contexts/PlayerContext";
import { SERVICES, ServiceId, useServices } from "@/contexts/ServicesContext";
import { useColors } from "@/hooks/useColors";

const MONO = "SpaceMono_400Regular";
const NDOT = "SpaceMono_700Bold";

const SERVICE_ICONS: Record<ServiceId, string> = {
  vk: "headphones",
  yandex: "music",
  spotify: "radio",
};

export default function ServicesScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const { connect, disconnect, isConnected, getToken } = useServices();
  const { addToLibrary } = usePlayer();

  const [activeService, setActiveService] = useState<ServiceId | null>(null);
  const [token, setToken] = useState("");
  const [loading, setLoading] = useState(false);

  const service = SERVICES.find((s) => s.id === activeService);

  async function handleConnect() {
    if (!activeService || !token.trim()) return;
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      await connect(activeService, token.trim());
      setToken("");
      setActiveService(null);
      Alert.alert("CONNECTED", `${service?.name} successfully connected.`);
    } catch {
      Alert.alert("ERROR", "Failed to connect. Check your token.");
    } finally {
      setLoading(false);
    }
  }

  async function handleDisconnect(id: ServiceId) {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    await disconnect(id);
  }

  async function handleImport(id: ServiceId) {
    const tk = getToken(id);
    if (!tk) return;
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const base = domain ? `https://${domain}` : "";
      const res = await fetch(`${base}/api/music/services/${id}/tracks`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: tk }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.tracks?.length) {
          addToLibrary(
            data.tracks.map((t: any) => ({ ...t, source: id }))
          );
          Alert.alert("IMPORTED", `${data.tracks.length} tracks added to library.`);
        } else {
          Alert.alert("EMPTY", "No tracks found for this account.");
        }
      } else {
        const err = await res.json();
        Alert.alert("ERROR", err.message ?? "Import failed.");
      }
    } catch {
      Alert.alert("ERROR", "Connection failed. Check server.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <View
      style={[
        styles.root,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === "web" ? 67 : insets.top,
        },
      ]}
    >
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: NDOT }]}>
          SOURCES
        </Text>
        <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: MONO }]}>
          CONNECT MUSIC SERVICES
        </Text>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.scroll,
          { paddingBottom: Platform.OS === "web" ? 34 : 20 },
        ]}
      >
        {SERVICES.map((svc) => {
          const connected = isConnected(svc.id);
          return (
            <View
              key={svc.id}
              style={[
                styles.card,
                {
                  backgroundColor: colors.card,
                  borderColor: connected ? svc.color + "44" : colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              {/* Card header */}
              <View style={styles.cardTop}>
                <View
                  style={[
                    styles.iconCircle,
                    { backgroundColor: svc.color + "22", borderColor: svc.color + "44" },
                  ]}
                >
                  <Feather name={SERVICE_ICONS[svc.id] as any} size={22} color={svc.color} />
                </View>
                <View style={styles.cardInfo}>
                  <Text style={[styles.cardName, { color: colors.foreground, fontFamily: NDOT }]}>
                    {svc.name}
                  </Text>
                  <Text style={[styles.cardDesc, { color: colors.mutedForeground, fontFamily: MONO }]}>
                    {svc.description}
                  </Text>
                </View>
                <View
                  style={[
                    styles.statusDot,
                    { backgroundColor: connected ? "#44FF44" : colors.border },
                  ]}
                />
              </View>

              {/* Actions */}
              <View style={styles.cardActions}>
                {connected ? (
                  <>
                    <TouchableOpacity
                      onPress={() => handleImport(svc.id)}
                      disabled={loading}
                      style={[
                        styles.btn,
                        { backgroundColor: svc.color + "22", borderColor: svc.color + "44" },
                      ]}
                    >
                      <Feather name="download" size={14} color={svc.color} />
                      <Text style={[styles.btnText, { color: svc.color, fontFamily: MONO }]}>
                        IMPORT
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleDisconnect(svc.id)}
                      style={[styles.btn, { backgroundColor: "transparent", borderColor: colors.border }]}
                    >
                      <Feather name="x" size={14} color={colors.mutedForeground} />
                      <Text style={[styles.btnText, { color: colors.mutedForeground, fontFamily: MONO }]}>
                        DISCONNECT
                      </Text>
                    </TouchableOpacity>
                  </>
                ) : (
                  <TouchableOpacity
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setActiveService(svc.id);
                      setToken("");
                    }}
                    style={[
                      styles.connectBtn,
                      { backgroundColor: colors.foreground },
                    ]}
                  >
                    <Text style={[styles.connectBtnText, { color: colors.background, fontFamily: MONO }]}>
                      CONNECT
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        })}

        {/* Info block */}
        <View style={[styles.infoBlock, { borderColor: colors.border }]}>
          <Feather name="info" size={14} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground, fontFamily: MONO }]}>
            Токены хранятся локально на устройстве. Никуда не отправляются кроме запросов к сервису.
          </Text>
        </View>
      </ScrollView>

      {/* Token input modal */}
      <Modal
        visible={activeService !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setActiveService(null)}
      >
        <Pressable style={styles.overlay} onPress={() => setActiveService(null)}>
          <Pressable style={[styles.sheet, { backgroundColor: "#1A1A1A", borderRadius: 28 }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground, fontFamily: NDOT }]}>
              CONNECT {service?.name}
            </Text>
            <Text style={[styles.sheetDesc, { color: colors.mutedForeground, fontFamily: MONO }]}>
              {service?.howToGet}
            </Text>
            <TextInput
              style={[
                styles.tokenInput,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  color: colors.foreground,
                  fontFamily: MONO,
                },
              ]}
              placeholder={service?.tokenLabel ?? "TOKEN"}
              placeholderTextColor={colors.mutedForeground}
              value={token}
              onChangeText={setToken}
              autoCapitalize="none"
              autoCorrect={false}
              multiline
              numberOfLines={3}
            />
            <TouchableOpacity
              onPress={handleConnect}
              disabled={loading || !token.trim()}
              style={[
                styles.connectSheet,
                {
                  backgroundColor:
                    loading || !token.trim() ? colors.border : colors.foreground,
                },
              ]}
            >
              <Text
                style={[
                  styles.connectSheetText,
                  {
                    color:
                      loading || !token.trim()
                        ? colors.mutedForeground
                        : colors.background,
                    fontFamily: MONO,
                  },
                ]}
              >
                {loading ? "CONNECTING..." : "CONFIRM"}
              </Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, paddingTop: 12, gap: 4 },
  headerTitle: { fontSize: 24, letterSpacing: 3 },
  headerSub: { fontSize: 10, letterSpacing: 2 },
  scroll: { paddingHorizontal: 16, gap: 12 },
  card: { borderWidth: 1, padding: 18, gap: 16 },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 14 },
  iconCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  cardInfo: { flex: 1, gap: 4 },
  cardName: { fontSize: 15, letterSpacing: 1 },
  cardDesc: { fontSize: 11, letterSpacing: 0.3 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  cardActions: { flexDirection: "row", gap: 10 },
  btn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 10,
    borderWidth: 1,
    borderRadius: 40,
  },
  btnText: { fontSize: 11, letterSpacing: 1 },
  connectBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 12,
    borderRadius: 40,
  },
  connectBtnText: { fontSize: 12, letterSpacing: 2 },
  infoBlock: {
    flexDirection: "row",
    gap: 10,
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
    marginTop: 4,
    alignItems: "flex-start",
  },
  infoText: { flex: 1, fontSize: 11, lineHeight: 18, letterSpacing: 0.3 },
  overlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.75)", justifyContent: "flex-end" },
  sheet: { padding: 24, paddingBottom: 40, gap: 16 },
  handle: { width: 40, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 8 },
  sheetTitle: { fontSize: 18, letterSpacing: 2 },
  sheetDesc: { fontSize: 12, lineHeight: 20, letterSpacing: 0.3 },
  tokenInput: {
    borderWidth: 1,
    borderRadius: 16,
    padding: 14,
    fontSize: 12,
    letterSpacing: 0.5,
    minHeight: 80,
    textAlignVertical: "top",
  },
  connectSheet: { alignItems: "center", paddingVertical: 14, borderRadius: 40 },
  connectSheetText: { fontSize: 13, letterSpacing: 2 },
});
