import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { Image } from "expo-image";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";

const MONO = "SpaceMono_400Regular";
const NDOT = "SpaceMono_700Bold";

interface Podcast {
  id: string;
  title: string;
  author: string;
  cover_url: string;
  episodes_count: number;
  description: string;
}

const FEATURED_PODCASTS: Podcast[] = [
  {
    id: "lebedev_1",
    title: "КОВОДСТВО",
    author: "АРТЕМИЙ ЛЕБЕДЕВ",
    cover_url: "",
    episodes_count: 312,
    description: "Подкаст о дизайне, технологиях и жизни от Артемия Лебедева",
  },
  {
    id: "lebedev_2",
    title: "ВОПРОСЫ ЛЕБЕДЕВУ",
    author: "АРТЕМИЙ ЛЕБЕДЕВ",
    cover_url: "",
    episodes_count: 180,
    description: "Артемий Лебедев отвечает на вопросы подписчиков",
  },
  {
    id: "lebedev_3",
    title: "ПУТЕВЫЕ ЗАМЕТКИ",
    author: "АРТЕМИЙ ЛЕБЕДЕВ",
    cover_url: "",
    episodes_count: 94,
    description: "Путешествия Артемия Лебедева по всему миру",
  },
  {
    id: "tech_1",
    title: "РАДИО-Т",
    author: "UMPUTUN, KSENKS, BOBUK",
    cover_url: "",
    episodes_count: 850,
    description: "Еженедельный подкаст о технологиях",
  },
  {
    id: "tech_2",
    title: "ZAVTRACAST",
    author: "NIKOLAY MOCHKIN",
    cover_url: "",
    episodes_count: 210,
    description: "Технологии, гаджеты, интернет",
  },
  {
    id: "music_1",
    title: "МУЗЫКАЛЬНЫЙ ПОДКАСТ",
    author: "VK MUSIC",
    cover_url: "",
    episodes_count: 120,
    description: "Новая музыка и подборки из ВКонтакте",
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  lebedev_1: "#E8C84A",
  lebedev_2: "#E8C84A",
  lebedev_3: "#E8C84A",
  tech_1: "#4A9EE8",
  tech_2: "#4A9EE8",
  music_1: "#E84A7A",
};

export default function PodcastsScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const [podcasts] = useState<Podcast[]>(FEATURED_PODCASTS);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const renderPodcast = ({ item }: { item: Podcast }) => {
    const isSelected = selectedId === item.id;
    const accent = CATEGORY_COLORS[item.id] ?? colors.accent;
    const isLebedev = item.id.startsWith("lebedev");

    return (
      <TouchableOpacity
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          setSelectedId(isSelected ? null : item.id);
        }}
        style={[
          styles.card,
          {
            backgroundColor: colors.card,
            borderColor: isSelected ? accent + "66" : colors.border,
            borderRadius: colors.radius - 4,
          },
        ]}
        activeOpacity={0.8}
      >
        <View style={styles.cardMain}>
          {/* Cover */}
          <View
            style={[
              styles.cover,
              {
                backgroundColor: accent + "22",
                borderColor: accent + "44",
              },
            ]}
          >
            {isLebedev ? (
              <Text style={[styles.coverInitials, { color: accent, fontFamily: NDOT }]}>AL</Text>
            ) : (
              <Feather name="mic" size={24} color={accent} />
            )}
          </View>

          <View style={styles.info}>
            {isLebedev && (
              <View style={[styles.featuredBadge, { backgroundColor: accent + "22", borderColor: accent + "44" }]}>
                <Text style={[styles.featuredText, { color: accent, fontFamily: MONO }]}>FEATURED</Text>
              </View>
            )}
            <Text
              numberOfLines={2}
              style={[styles.title, { color: colors.foreground, fontFamily: NDOT }]}
            >
              {item.title}
            </Text>
            <Text
              numberOfLines={1}
              style={[styles.author, { color: colors.mutedForeground, fontFamily: MONO }]}
            >
              {item.author}
            </Text>
            <View style={styles.meta}>
              <Feather name="headphones" size={10} color={colors.mutedForeground} />
              <Text style={[styles.episodes, { color: colors.mutedForeground, fontFamily: MONO }]}>
                {item.episodes_count} EPS
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={[styles.playBtn, { borderColor: accent + "44" }]}
            onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)}
          >
            <Feather name="play" size={16} color={accent} />
          </TouchableOpacity>
        </View>

        {isSelected && (
          <View style={[styles.desc, { borderTopColor: colors.border }]}>
            <Text style={[styles.descText, { color: colors.mutedForeground, fontFamily: MONO }]}>
              {item.description}
            </Text>
            <TouchableOpacity
              style={[styles.vkBtn, { backgroundColor: "#0077FF22", borderColor: "#0077FF44" }]}
              onPress={() => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)}
            >
              <Text style={[styles.vkBtnText, { color: "#0077FF", fontFamily: MONO }]}>
                ОТКРЫТЬ В VK МУЗЫКЕ
              </Text>
              <Feather name="external-link" size={12} color="#0077FF" />
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View
      style={[
        styles.root,
        {
          backgroundColor: colors.background,
          paddingTop: Platform.OS === "web" ? 67 : insets.top,
        },
      ]}
    >
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.foreground, fontFamily: NDOT }]}>
          PODCASTS
        </Text>
        <Text style={[styles.headerSub, { color: colors.mutedForeground, fontFamily: MONO }]}>
          АРТЕМИЙ ЛЕБЕДЕВ И ДРУГИЕ
        </Text>
      </View>

      {/* Featured label */}
      <View style={[styles.sectionLabel, { borderBottomColor: colors.border }]}>
        <View style={[styles.sectionDot, { backgroundColor: colors.accent }]} />
        <Text style={[styles.sectionText, { color: colors.accent, fontFamily: MONO }]}>
          ARTEMY LEBEDEV
        </Text>
        <View style={[styles.sectionLine, { backgroundColor: colors.border }]} />
      </View>

      <FlatList
        data={podcasts}
        keyExtractor={(p) => p.id}
        renderItem={renderPodcast}
        contentContainerStyle={[
          styles.list,
          { paddingBottom: Platform.OS === "web" ? 34 : 20 },
        ]}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        ListFooterComponent={
          <View style={[styles.footer, { borderTopColor: colors.border }]}>
            <Feather name="info" size={12} color={colors.mutedForeground} />
            <Text style={[styles.footerText, { color: colors.mutedForeground, fontFamily: MONO }]}>
              Подключи VK Музыку в Sources для загрузки подкастов
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 12, paddingTop: 12, gap: 4 },
  headerTitle: { fontSize: 24, letterSpacing: 3 },
  headerSub: { fontSize: 10, letterSpacing: 2 },
  sectionLabel: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 10,
    gap: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    marginBottom: 4,
  },
  sectionDot: { width: 6, height: 6, borderRadius: 3 },
  sectionText: { fontSize: 10, letterSpacing: 2 },
  sectionLine: { flex: 1, height: 1 },
  list: { padding: 12, gap: 0 },
  card: { borderWidth: 1, overflow: "hidden" },
  cardMain: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    gap: 14,
  },
  cover: {
    width: 56,
    height: 56,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  coverInitials: { fontSize: 18, letterSpacing: 2 },
  info: { flex: 1, gap: 4 },
  featuredBadge: {
    alignSelf: "flex-start",
    borderWidth: 1,
    borderRadius: 4,
    paddingHorizontal: 6,
    paddingVertical: 1,
    marginBottom: 2,
  },
  featuredText: { fontSize: 8, letterSpacing: 1 },
  title: { fontSize: 14, letterSpacing: 0.5, lineHeight: 20 },
  author: { fontSize: 10, letterSpacing: 1 },
  meta: { flexDirection: "row", alignItems: "center", gap: 4 },
  episodes: { fontSize: 10, letterSpacing: 0.5 },
  playBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  desc: {
    borderTopWidth: StyleSheet.hairlineWidth,
    padding: 14,
    gap: 12,
  },
  descText: { fontSize: 12, lineHeight: 18, letterSpacing: 0.3 },
  vkBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    alignSelf: "flex-start",
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  vkBtnText: { fontSize: 11, letterSpacing: 1 },
  footer: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
    padding: 16,
    marginTop: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  footerText: { flex: 1, fontSize: 11, lineHeight: 16, letterSpacing: 0.3 },
});
