import { Feather } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import React from "react";
import { Platform, StyleSheet, View } from "react-native";

import { useColors } from "@/hooks/useColors";

function TabIcon({
  name,
  focused,
}: {
  name: string;
  focused: boolean;
}) {
  const colors = useColors();
  return (
    <View style={styles.tabIcon}>
      <Feather
        name={name as any}
        size={22}
        color={focused ? colors.accent : colors.mutedForeground}
      />
      {focused && (
        <View style={[styles.activeDot, { backgroundColor: colors.accent }]} />
      )}
    </View>
  );
}

export default function TabLayout() {
  const colors = useColors();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarStyle: {
          backgroundColor: "#000000",
          borderTopWidth: StyleSheet.hairlineWidth,
          borderTopColor: colors.border,
          height: Platform.OS === "web" ? 84 : 62,
          paddingBottom: Platform.OS === "web" ? 34 : 6,
          paddingTop: 6,
        },
        tabBarLabelStyle: {
          fontFamily: "SpaceMono_400Regular",
          fontSize: 8,
          letterSpacing: 1,
          textTransform: "uppercase",
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "PLAYER",
          tabBarIcon: ({ focused }) => (
            <TabIcon name="music" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="library"
        options={{
          title: "LIBRARY",
          tabBarIcon: ({ focused }) => (
            <TabIcon name="list" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="services"
        options={{
          title: "SOURCES",
          tabBarIcon: ({ focused }) => (
            <TabIcon name="link" focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="podcasts"
        options={{
          title: "PODCAST",
          tabBarIcon: ({ focused }) => (
            <TabIcon name="mic" focused={focused} />
          ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabIcon: {
    alignItems: "center",
    justifyContent: "center",
    width: 28,
    height: 28,
  },
  activeDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    marginTop: 2,
  },
});
