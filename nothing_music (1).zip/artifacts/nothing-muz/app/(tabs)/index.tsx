import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import React, { useCallback, useRef, useState } from "react";
import {
  Animated,
  Modal,
  Platform,
  PanResponder,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { usePlayer } from "@/contexts/PlayerContext";
import { useColors } from "@/hooks/useColors";

function formatTime(secs: number) {
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

const SOURCE_COLORS: Record<string, string[]> = {
  vk: ["#003A8C", "#001A4D"],
  yandex: ["#3D3000", "#1F1800"],
  spotify: ["#0A3D1A", "#051A0D"],
  local: ["#1E1A00", "#0F0D00"],
};

const NDOT = "SpaceMono_700Bold";
const MONO = "SpaceMono_400Regular";

export default function PlayerScreen() {
  const insets = useSafeAreaInsets();
  const colors = useColors();
  const {
    currentTrack,
    isPlaying,
    progress,
    duration,
    isShuffle,
    isRepeat,
    playlist,
    togglePlay,
    next,
    prev,
    seekTo,
    toggleShuffle,
    toggleRepeat,
  } = usePlayer();

  const [menuVisible, setMenuVisible] = useState(false);
  const [ndotEnabled, setNdotEnabled] = useState(true);
  const barWidth = useRef(0);

  const srcColors = SOURCE_COLORS[currentTrack?.source ?? "local"];
  const progressPercent = duration > 0 ? progress / duration : 0;
  const titleFont = ndotEnabled ? NDOT : MONO;

  const handleSeek = useCallback(
    (x: number) => {
      if (barWidth.current > 0) {
        const ratio = Math.max(0, Math.min(1, x / barWidth.current));
        seekTo(ratio * duration);
      }
    },
    [duration, seekTo]
  );

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => handleSeek(evt.nativeEvent.locationX),
      onPanResponderMove: (evt) => handleSeek(evt.nativeEvent.locationX),
    })
  ).current;

  return (
    <View style={[styles.root, { backgroundColor: "#000000" }]}>
      <StatusBar barStyle="light-content" />

      {/* ── TOP BAR ── */}
      <View
        style={[
          styles.topBar,
          {
            paddingTop:
              Platform.OS === "web" ? 67 : insets.top + 8,
          },
        ]}
      >
        <TouchableOpacity
          onPress={() => setMenuVisible(true)}
          style={styles.menuBtn}
          activeOpacity={0.7}
        >
          <View
            style={[styles.menuLine, { backgroundColor: colors.foreground }]}
          />
          <View
            style={[
              styles.menuLine,
              { backgroundColor: colors.foreground, width: 18 },
            ]}
          />
        </TouchableOpacity>

        <View style={styles.appTitleBlock}>
          <Text style={[styles.appTitle, { color: colors.foreground, fontFamily: NDOT }]}>
            NOTHING MUSIC
          </Text>
          <Text style={[styles.appSub, { color: colors.mutedForeground, fontFamily: MONO }]}>
            by @kstikov
          </Text>
        </View>
      </View>

      {/* ── PLAYER CARD ── */}
      <View style={styles.cardWrap}>
        <LinearGradient
          colors={[srcColors[0], srcColors[1], "#000000"]}
          style={[styles.playerCard, { borderRadius: colors.radius }]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          {/* Track info */}
          <View style={styles.trackInfo}>
            <Text
              numberOfLines={2}
              style={[styles.trackTitle, { color: colors.foreground, fontFamily: titleFont }]}
            >
              {currentTrack?.title.toUpperCase() ?? "NO TRACK"}
            </Text>
            <Text
              numberOfLines={1}
              style={[styles.trackArtist, { color: colors.mutedForeground, fontFamily: MONO }]}
            >
              {"<"}{currentTrack?.artist.toUpperCase() ?? "UNKNOWN"}{">"}
            </Text>
          </View>

          {/* Album art / logo */}
          <View style={styles.artBlock}>
            {currentTrack?.cover_url ? (
              <View style={[styles.artFrame, { borderRadius: 16, borderColor: "rgba(255,255,255,0.1)" }]}>
              </View>
            ) : (
              <View style={[styles.artFrame, { borderColor: "rgba(255,255,255,0.12)", borderRadius: 16 }]}>
                <Text style={[styles.nmLogo, { color: "rgba(255,255,255,0.2)", fontFamily: NDOT }]}>
                  NM
                </Text>
                <View style={styles.dotGrid}>
                  {Array.from({ length: 25 }).map((_, i) => (
                    <View
                      key={i}
                      style={[styles.dot, { backgroundColor: "rgba(255,255,255,0.15)" }]}
                    />
                  ))}
                </View>
              </View>
            )}
          </View>
        </LinearGradient>
      </View>

      {/* ── PROGRESS BAR ── */}
      <View style={styles.progressSection}>
        <View
          style={styles.progressBar}
          onLayout={(e) => {
            barWidth.current = e.nativeEvent.layout.width;
          }}
          {...panResponder.panHandlers}
        >
          <View
            style={[styles.progressTrack, { backgroundColor: colors.border }]}
          />
          <View
            style={[
              styles.progressFill,
              {
                width: `${progressPercent * 100}%`,
                backgroundColor: colors.foreground,
              },
            ]}
          />
          <View
            style={[
              styles.progressThumb,
              {
                left: `${progressPercent * 100}%`,
                backgroundColor: colors.foreground,
              },
            ]}
          />
        </View>
        <View style={styles.timesRow}>
          <Text style={[styles.timeText, { color: colors.mutedForeground, fontFamily: MONO }]}>
            {formatTime(progress)}
          </Text>
          <Text style={[styles.timeText, { color: colors.mutedForeground, fontFamily: MONO }]}>
            {formatTime(duration || currentTrack?.duration || 0)}
          </Text>
        </View>
      </View>

      {/* ── CONTROLS ── */}
      <View style={styles.controls}>
        {/* Shuffle */}
        <TouchableOpacity
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); toggleShuffle(); }}
          style={styles.sideBtn}
        >
          <Feather
            name="shuffle"
            size={20}
            color={isShuffle ? colors.accent : colors.mutedForeground}
          />
        </TouchableOpacity>

        {/* Prev */}
        <TouchableOpacity
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); prev(); }}
          style={styles.skipBtn}
        >
          <Feather name="skip-back" size={26} color={colors.foreground} />
        </TouchableOpacity>

        {/* Play / Pause capsule */}
        <TouchableOpacity
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); togglePlay(); }}
          activeOpacity={0.85}
          style={[styles.playCapsule, { backgroundColor: colors.foreground }]}
        >
          {isPlaying ? (
            <View style={styles.pauseIcon}>
              <View style={[styles.pauseBar, { backgroundColor: "#000000" }]} />
              <View style={[styles.pauseBar, { backgroundColor: "#000000" }]} />
            </View>
          ) : (
            <Feather name="play" size={28} color="#000000" style={{ marginLeft: 4 }} />
          )}
        </TouchableOpacity>

        {/* Next */}
        <TouchableOpacity
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); next(); }}
          style={styles.skipBtn}
        >
          <Feather name="skip-forward" size={26} color={colors.foreground} />
        </TouchableOpacity>

        {/* Repeat */}
        <TouchableOpacity
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); toggleRepeat(); }}
          style={styles.sideBtn}
        >
          <Feather
            name="repeat"
            size={20}
            color={isRepeat ? colors.accent : colors.mutedForeground}
          />
        </TouchableOpacity>
      </View>

      {/* ── PLAYLIST CAPSULE ── */}
      <View style={styles.playlistRow}>
        <TouchableOpacity
          style={[
            styles.playlistCapsule,
            { backgroundColor: colors.surface ?? "#181818", borderColor: colors.border },
          ]}
          activeOpacity={0.7}
        >
          <Text style={[styles.plIcon, { color: colors.accent, fontFamily: NDOT }]}>PL</Text>
          <Text style={[styles.plText, { color: colors.foreground, fontFamily: MONO }]}>
            ALL TRACKS ({playlist.length})
          </Text>
          <Feather name="chevron-up" size={14} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      {/* ── SETTINGS MODAL ── */}
      <Modal
        visible={menuVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setMenuVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setMenuVisible(false)}
        >
          <Pressable style={[styles.modalCard, { backgroundColor: "#1A1A1A", borderRadius: 28 }]}>
            <View style={[styles.modalHandle, { backgroundColor: colors.border }]} />
            <Text style={[styles.modalTitle, { color: colors.foreground, fontFamily: NDOT }]}>
              SETTINGS
            </Text>

            {/* NDOT Font toggle */}
            <View style={[styles.settingRow, { borderBottomColor: colors.border }]}>
              <View>
                <Text style={[styles.settingLabel, { color: colors.foreground, fontFamily: MONO }]}>
                  NDOT FONT
                </Text>
                <Text style={[styles.settingDesc, { color: colors.mutedForeground, fontFamily: MONO }]}>
                  Pixel style typography
                </Text>
              </View>
              <Switch
                value={ndotEnabled}
                onValueChange={(v) => { setNdotEnabled(v); Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }}
                trackColor={{ false: colors.border, true: colors.accent }}
                thumbColor={ndotEnabled ? "#000000" : "#888888"}
              />
            </View>

            {/* Developer block */}
            <Text style={[styles.devSectionTitle, { color: colors.mutedForeground, fontFamily: MONO }]}>
              DEVELOPER
            </Text>
            <View style={styles.devCards}>
              <TouchableOpacity
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); require('expo-linking').openURL('https://t.me/kstikov'); }}
                style={[styles.devCard, { backgroundColor: "#0A1628", borderColor: "#1A4080" }]}
              >
                <Feather name="send" size={18} color="#4A9EFF" />
                <Text style={[styles.devCardText, { color: "#4A9EFF", fontFamily: MONO }]}>
                  @kstikov
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); require('expo-linking').openURL('https://tiktok.com/@kstikov'); }}
                style={[styles.devCard, { backgroundColor: "#0A0014", borderColor: "#3A0080" }]}
              >
                <Feather name="video" size={18} color="#CC55FF" />
                <Text style={[styles.devCardText, { color: "#CC55FF", fontFamily: MONO }]}>
                  @kstikov
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={[styles.versionText, { color: colors.mutedForeground, fontFamily: MONO }]}>
              NOTHING MUSIC v1.0 · by @kstikov
            </Text>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingHorizontal: 20,
    paddingBottom: 8,
  },
  menuBtn: {
    gap: 6,
    paddingTop: 4,
  },
  menuLine: {
    width: 24,
    height: 2,
    borderRadius: 1,
  },
  appTitleBlock: {
    alignItems: "flex-end",
  },
  appTitle: {
    fontSize: 13,
    letterSpacing: 2,
  },
  appSub: {
    fontSize: 10,
    letterSpacing: 1,
    marginTop: 2,
  },
  cardWrap: {
    paddingHorizontal: 16,
    flex: 1,
    maxHeight: 360,
  },
  playerCard: {
    flex: 1,
    padding: 20,
    gap: 14,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "rgba(232,200,74,0.12)",
  },
  trackInfo: {
    gap: 6,
  },
  trackTitle: {
    fontSize: 22,
    letterSpacing: 1,
    lineHeight: 28,
  },
  trackArtist: {
    fontSize: 13,
    letterSpacing: 0.5,
  },
  artBlock: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  artFrame: {
    width: 140,
    height: 140,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },
  nmLogo: {
    fontSize: 40,
    letterSpacing: 4,
    position: "absolute",
    opacity: 0.6,
  },
  dotGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    width: 140,
    height: 140,
    gap: 8,
    padding: 12,
  },
  dot: {
    width: 4,
    height: 4,
    borderRadius: 2,
  },
  progressSection: {
    paddingHorizontal: 20,
    paddingTop: 20,
    gap: 6,
  },
  progressBar: {
    height: 20,
    justifyContent: "center",
    position: "relative",
  },
  progressTrack: {
    height: 2,
    borderRadius: 1,
    position: "absolute",
    left: 0,
    right: 0,
  },
  progressFill: {
    height: 2,
    borderRadius: 1,
    position: "absolute",
    left: 0,
  },
  progressThumb: {
    width: 12,
    height: 12,
    borderRadius: 6,
    position: "absolute",
    marginLeft: -6,
    top: 4,
  },
  timesRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  timeText: {
    fontSize: 11,
    letterSpacing: 1,
  },
  controls: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
    paddingTop: 16,
    gap: 12,
  },
  sideBtn: {
    width: 40,
    height: 40,
    alignItems: "center",
    justifyContent: "center",
  },
  skipBtn: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  playCapsule: {
    width: 64,
    height: 80,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
  },
  pauseIcon: {
    flexDirection: "row",
    gap: 6,
  },
  pauseBar: {
    width: 4,
    height: 24,
    borderRadius: 2,
  },
  playlistRow: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
    alignItems: "center",
  },
  playlistCapsule: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 40,
    borderWidth: 1,
  },
  plIcon: {
    fontSize: 11,
    letterSpacing: 1,
  },
  plText: {
    fontSize: 11,
    letterSpacing: 1,
    flex: 1,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "flex-end",
  },
  modalCard: {
    padding: 24,
    paddingBottom: 40,
    gap: 16,
  },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 18,
    letterSpacing: 3,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  settingLabel: {
    fontSize: 14,
    letterSpacing: 1,
  },
  settingDesc: {
    fontSize: 11,
    letterSpacing: 0.5,
    marginTop: 2,
  },
  devSectionTitle: {
    fontSize: 10,
    letterSpacing: 2,
    marginTop: 8,
  },
  devCards: {
    flexDirection: "row",
    gap: 12,
  },
  devCard: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
  },
  devCardText: {
    fontSize: 13,
    letterSpacing: 0.5,
  },
  versionText: {
    fontSize: 10,
    letterSpacing: 1,
    textAlign: "center",
    marginTop: 8,
  },
});
