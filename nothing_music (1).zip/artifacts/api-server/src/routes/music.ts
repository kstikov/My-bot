import { Router } from "express";

const router = Router();

router.post("/services/vk/tracks", async (req, res) => {
  const { token } = req.body as { token?: string };
  if (!token) {
    res.status(401).json({ error: "unauthorized", message: "VK token is required" });
    return;
  }

  try {
    const vkRes = await fetch(
      `https://api.vk.com/method/audio.get?access_token=${token}&v=5.199&count=100`,
      { headers: { "User-Agent": "VKAndroidApp/70.2-r-2023" } }
    );
    const data = (await vkRes.json()) as any;

    if (data.error) {
      const errCode = data.error.error_code;
      if (errCode === 5 || errCode === 15) {
        res.status(401).json({ error: "unauthorized", message: "Invalid or expired VK token" });
        return;
      }
      if (errCode === 201) {
        res.status(403).json({ error: "forbidden", message: "VK Audio API access denied. Your account needs special permission." });
        return;
      }
      res.status(400).json({ error: "vk_error", message: data.error.error_msg ?? "VK API error" });
      return;
    }

    const items: any[] = data.response?.items ?? [];
    const tracks = items.map((item: any) => ({
      id: `vk_${item.owner_id}_${item.id}`,
      title: item.title ?? "Unknown",
      artist: item.artist ?? "Unknown",
      cover_url: item.album?.thumb?.photo_300 ?? "",
      duration: item.duration ?? 0,
      stream_url: item.url ?? "",
    }));

    res.json({ playlist_name: "VK Music", tracks });
  } catch (err: any) {
    res.status(500).json({ error: "internal", message: "Failed to connect to VK API" });
  }
});

router.post("/services/yandex/tracks", async (req, res) => {
  const { token } = req.body as { token?: string };
  if (!token) {
    res.status(401).json({ error: "unauthorized", message: "Yandex token is required" });
    return;
  }

  try {
    const statusRes = await fetch("https://api.music.yandex.net/account/status", {
      headers: {
        Authorization: `OAuth ${token}`,
        "X-Yandex-Music-Client": "WindowsPhone/3.19",
      },
    });

    if (statusRes.status === 401) {
      res.status(401).json({ error: "unauthorized", message: "Invalid or expired Yandex Music token" });
      return;
    }

    const likedRes = await fetch(
      "https://api.music.yandex.net/users/0/likes/tracks?if-modified-since-revision=0",
      {
        headers: {
          Authorization: `OAuth ${token}`,
          "X-Yandex-Music-Client": "WindowsPhone/3.19",
        },
      }
    );

    const likedData = (await likedRes.json()) as any;
    const trackIds: any[] = likedData.result?.library?.tracks ?? [];

    if (trackIds.length === 0) {
      res.json({ playlist_name: "Yandex Music", tracks: [] });
      return;
    }

    const idsParam = trackIds
      .slice(0, 50)
      .map((t: any) => (t.albumId ? `${t.id}:${t.albumId}` : `${t.id}`))
      .join(",");

    const tracksRes = await fetch(
      `https://api.music.yandex.net/tracks?trackIds=${idsParam}`,
      {
        headers: {
          Authorization: `OAuth ${token}`,
          "X-Yandex-Music-Client": "WindowsPhone/3.19",
        },
      }
    );

    const tracksData = (await tracksRes.json()) as any;
    const result: any[] = tracksData.result ?? [];

    const tracks = result.map((t: any) => ({
      id: `yandex_${t.id}`,
      title: t.title ?? "Unknown",
      artist: t.artists?.map((a: any) => a.name).join(", ") ?? "Unknown",
      cover_url: t.coverUri
        ? `https://${t.coverUri.replace("%%", "300x300")}`
        : "",
      duration: Math.floor((t.durationMs ?? 0) / 1000),
      stream_url: "",
    }));

    res.json({ playlist_name: "Yandex Music", tracks });
  } catch {
    res.status(500).json({ error: "internal", message: "Failed to connect to Yandex Music API" });
  }
});

router.post("/services/spotify/tracks", async (req, res) => {
  const { token } = req.body as { token?: string };
  if (!token) {
    res.status(401).json({ error: "unauthorized", message: "Spotify token is required" });
    return;
  }

  try {
    const spotRes = await fetch(
      "https://api.spotify.com/v1/me/tracks?limit=50&market=RU",
      { headers: { Authorization: `Bearer ${token}` } }
    );

    if (spotRes.status === 401) {
      res.status(401).json({ error: "unauthorized", message: "Invalid or expired Spotify token" });
      return;
    }

    if (spotRes.status === 403) {
      res.status(403).json({ error: "forbidden", message: "Spotify Premium required for track access" });
      return;
    }

    const data = (await spotRes.json()) as any;
    const items: any[] = data.items ?? [];

    const tracks = items.map((item: any) => {
      const t = item.track;
      return {
        id: `spotify_${t.id}`,
        title: t.name ?? "Unknown",
        artist: t.artists?.map((a: any) => a.name).join(", ") ?? "Unknown",
        cover_url: t.album?.images?.[0]?.url ?? "",
        duration: Math.floor((t.duration_ms ?? 0) / 1000),
        stream_url: t.preview_url ?? "",
      };
    });

    res.json({ playlist_name: "Spotify Liked Songs", tracks });
  } catch {
    res.status(500).json({ error: "internal", message: "Failed to connect to Spotify API" });
  }
});

router.get("/podcasts", async (req, res) => {
  const podcasts = [
    {
      id: "lebedev_1",
      title: "Ководство",
      author: "Артемий Лебедев",
      cover_url: "",
      episodes_count: 312,
      description: "Подкаст о дизайне, технологиях и жизни от Артемия Лебедева",
    },
    {
      id: "lebedev_2",
      title: "Вопросы Лебедеву",
      author: "Артемий Лебедев",
      cover_url: "",
      episodes_count: 180,
      description: "Артемий Лебедев отвечает на вопросы подписчиков",
    },
    {
      id: "radio_t",
      title: "Радио-Т",
      author: "umputun, ksenks, bobuk",
      cover_url: "",
      episodes_count: 850,
      description: "Еженедельный подкаст о технологиях",
    },
  ];
  res.json({ podcasts });
});

export default router;
